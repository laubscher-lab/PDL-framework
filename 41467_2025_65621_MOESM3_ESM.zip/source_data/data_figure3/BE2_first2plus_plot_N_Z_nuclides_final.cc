//------------------------------------------------------------
//  BE2_first2plus_N_Z_nuclides.cc made by Jeongsu Ha
//
//  Reference 
//  [1] B. Pritychenko, M. Birch, B. Singh, and M. Horoi, Atom. Dat. Nucl. Dat. Tabl. 107, 1 (2016) - method
//  [2] R. D. O. Llewellyn et al., Phys. Rev. Lett. 124, 152501 (2020) - 76Sr, 78Y, and 80Zr
//------------------------------------------------------------


#include "TROOT.h"

void BE2_calculator(double E, double tau, double alpha, double &BE2){

    BE2 = (40.81*1e13/5.0)/pow(E,5.0)/(tau*(1.0+alpha))*1e4; 
    printf("B(E2) is %2.4lf e2fm4 \n", BE2);
}

void BE2_first2plus_plot_N_Z_nuclides_final(){

   const int n_N_Z = 5;
   const int n_N_Zplus2 = 5;
   const int n_MyData = 1; // N=Z
   const int n_MyData2= 1; // N=Z+2

   double BE2_64Ge_lower, BE2_64Ge_upper;   // 64Ge: K. Starosta et al., Phys. Rev. Lett. 99, 042503 (2007)
   double BE2_68Se_lower, BE2_68Se_upper;
   double BE2_72Kr_lower, BE2_72Kr_upper;
   double BE2_76Sr_lower, BE2_76Sr_upper;
   double BE2_80Zr_lower, BE2_80Zr_upper;

   double BE2_66Ge_lower, BE2_66Ge_upper;
   double BE2_70Se_lower, BE2_70Se_upper;
   double BE2_74Kr_lower, BE2_74Kr_upper;
   double BE2_78Sr_lower, BE2_78Sr_upper;
   double BE2_82Zr_lower, BE2_82Zr_upper;

   double BE2_84Mo_lower, BE2_84Mo_upper;
   double BE2_86Mo_lower, BE2_86Mo_upper;
   double BE2_84Mo_val;

   BE2_calculator(853.8, (2.8+0.4)/0.693,    0.0006 , BE2_68Se_lower);      // A. Obertelli et al., PRC (2009) 
   BE2_calculator(853.8, (2.8-0.4)/0.693,    0.0006 , BE2_68Se_upper);      // A. Obertelli et al., PRC (2009) 
   BE2_calculator(709.7,         5.6+1.0,    0.0014 , BE2_72Kr_lower);      // H. Iwasaki et al., PRL (2014)
   BE2_calculator(709.7,         5.6-1.0,    0.0014 , BE2_72Kr_upper);      // H. Iwasaki et al., PRL (2014)
   BE2_calculator(261.6, 278.0+28.0, 0.0310 , BE2_76Sr_lower);      // Weighted average of A. Lemasson et al., PRC(R) (2012) and R. D. O. Llewellyn et al., PRL (2020) 
   BE2_calculator(261.6, 278.0-28.0, 0.0310 , BE2_76Sr_upper);      // Weighted average of A. Lemasson et al., PRC(R) (2012) and R. D. O. Llewellyn et al., PRL (2020) 

   // from Llewellyn
   BE2_calculator(290.8, 207.0+19.0, 0.0246 , BE2_80Zr_lower);          // R. D. O. Llewellyn et al., PRL (2020)
   BE2_calculator(290.0, 207.0-19.0, 0.0238 , BE2_80Zr_upper);          // R. D. O. Llewellyn et al., PRL (2020)


   // N=Z+2, previous works
   BE2_calculator(956.9, (3.7+0.7)/0.693,   0.0004 , BE2_66Ge_lower);       // R. Wadsworth et al., Journal of Physics G (1979)
   BE2_calculator(956.9, (3.7-0.7)/0.693,   0.0004 , BE2_66Ge_upper);       // R. Wadsworth et al., Journal of Physics G (1979)
   BE2_calculator(944.5, (2.23+0.14)/0.693, 0.0005 , BE2_70Se_lower);       // Weighted average of J. Ljungvall et al., PRL (2008) and A. J. Nichols et al., PLB (2014)
   BE2_calculator(944.5, (2.23-0.14)/0.693, 0.0005 , BE2_70Se_upper);       // Weighted average of J. Ljungvall et al., PRL (2008) and A. J. Nichols et al., PLB (2014)
   BE2_calculator(455.6,          33.7-0.6,  0.004 , BE2_74Kr_lower);       // Weighted average of A. Gorgen et al., EPJA (2005) and H. Iwasaki et al., PRL (2014)
   BE2_calculator(455.6,          33.7+0.6,  0.004 , BE2_74Kr_upper);       // Weighted average of A. Gorgen et al., EPJA (2005) and H. Iwasaki et al., PRL (2014)
   BE2_calculator(277.6, (173.0+15.0)/0.693, 0.025 , BE2_78Sr_lower);       // Weighted average of C. J. Lister et al., PRL (1982) and A. Lemasson et al., PRC(R) (2012)
   BE2_calculator(277.6, (173.0-15.0)/0.693, 0.025 , BE2_78Sr_upper);       // Weighted average of C. J. Lister et al., PRL (1982) and A. Lemasson et al., PRC(R) (2012) 
   BE2_calculator(407.0, (27.0+3.0)/0.693, 0.0079 , BE2_82Zr_lower);        // Weighted average of S. D. Paul et al., PRC (1997) and  A. A. Chishti et al. PRC (1993) 
   BE2_calculator(407.0, (27.0-3.0)/0.693, 0.0079 , BE2_82Zr_upper);        // Weighted average of S. D. Paul et al., PRC (1997) and A. A. Chishti et al., PRC (1993)
   
///// VALUE USED IN THE PAPER //////
   BE2_calculator(443.9, 27.1+8.8, 0.0068 , BE2_84Mo_lower);
   BE2_calculator(443.9, 27.1-6.7, 0.0068 , BE2_84Mo_upper);
   BE2_calculator(443.9, 27.1    , 0.0068 , BE2_84Mo_val);

////// VALUE USED IN THE PAPER //////
   BE2_calculator(566.6, (19.9+2.0) ,  0.0033 , BE2_86Mo_lower);
   BE2_calculator(566.6, (19.9-2.0) ,  0.0033 , BE2_86Mo_upper);
   
   double x_N_Z[n_N_Z]={31.9,33.9,35.9,37.9,39.9};			        // proton number of N_Z isotopes
   double y_N_Z[n_N_Z]={410.,(BE2_68Se_upper+BE2_68Se_lower)/2.,(BE2_72Kr_upper+BE2_72Kr_lower)/2.,(BE2_76Sr_upper+BE2_76Sr_lower)/2.,(BE2_80Zr_upper+BE2_80Zr_lower)/2.};		        // BE2 value of N_Z isotopes
   double yError_N_Z_uperr[n_N_Z]={60.,(BE2_68Se_upper-BE2_68Se_lower)/2.,(BE2_72Kr_upper-BE2_72Kr_lower)/2.,(BE2_76Sr_upper-BE2_76Sr_lower)/2.,(BE2_80Zr_upper-BE2_80Zr_lower)/2.};	    // the error of the BE2 value
   double yError_N_Z_downerr[n_N_Z]={60.,(BE2_68Se_upper-BE2_68Se_lower)/2.,(BE2_72Kr_upper-BE2_72Kr_lower)/2.,(BE2_76Sr_upper-BE2_76Sr_lower)/2.,(BE2_80Zr_upper-BE2_80Zr_lower)/2.};	// the error of the BE2 value
   ///--------------------------------------------//
   double x_N_Zplus2[n_N_Zplus2]={32.1,34.1,36.1,38.1,40.1};			        // proton number of N_Zplus2 isotopes
   double y_N_Zplus2[n_N_Zplus2]={(BE2_66Ge_upper+BE2_66Ge_lower)/2.,(BE2_70Se_upper+BE2_70Se_lower)/2.,(BE2_74Kr_upper+BE2_74Kr_lower)/2.,(BE2_78Sr_upper+BE2_78Sr_lower)/2.,(BE2_82Zr_upper+BE2_82Zr_lower)/2.};// BE2 value of N_Zplus2 isotopes
   double yError_N_Zplus2_uperr[n_N_Zplus2]={(BE2_66Ge_upper-BE2_66Ge_lower)/2.,(BE2_70Se_upper-BE2_70Se_lower)/2.,(BE2_74Kr_upper-BE2_74Kr_lower)/2.,(BE2_78Sr_upper-BE2_78Sr_lower)/2.,(BE2_82Zr_upper-BE2_82Zr_lower)/2.};	// the error of the BE2 value
   double yError_N_Zplus2_downerr[n_N_Zplus2]={(BE2_66Ge_upper-BE2_66Ge_lower)/2.,(BE2_70Se_upper-BE2_70Se_lower)/2.,(BE2_74Kr_upper-BE2_74Kr_lower)/2.,(BE2_78Sr_upper-BE2_78Sr_lower)/2.,(BE2_82Zr_upper-BE2_82Zr_lower)/2.};// the error of the BE2 value

   ///--------------------------------------------//
   double x_N_Z_MyData[n_MyData]={41.9};			        // proton number of N_Z isotopes
   double y_N_Z_MyData[n_MyData]={BE2_84Mo_val};		        // BE2 value of N_Z isotopes
   double yError_N_Z_MyData_uperr[n_MyData]={(BE2_84Mo_upper-BE2_84Mo_val)};	// the error of the BE2 value
   double yError_N_Z_MyData_downerr[n_MyData]={(BE2_84Mo_val-BE2_84Mo_lower)};// the error of the BE2 value
   ///--------------------------------------------//
   double x_N_Zplus2_MyData[n_MyData2]={42.1};			        // proton number of N_Zplus2 isotopes
   double y_N_Zplus2_MyData[n_MyData2]={(BE2_86Mo_upper+BE2_86Mo_lower)/2.};		        // BE2 value of N_Zplus2 isotopes
   double yError_N_Zplus2_MyData_uperr[n_MyData2]={(BE2_86Mo_upper-BE2_86Mo_lower)/2.};	// the error of the BE2 value
   double yError_N_Zplus2_MyData_downerr[n_MyData2]={(BE2_86Mo_upper-BE2_86Mo_lower)/2.};// the error of the BE2 value


   TCanvas *c1 = new TCanvas("c1","",700,450);
   c1->SetTopMargin(0.03);
   c1->SetBottomMargin(0.185);
   c1->SetLeftMargin(0.13);
   c1->SetTicks(1,1);
   gStyle->SetTickLength(0.015,"X");
   gStyle->SetTickLength(0.015,"Y");   

   TGraphAsymmErrors *g_N_Z = new TGraphAsymmErrors(n_N_Z,x_N_Z,y_N_Z,0,0,yError_N_Z_downerr,yError_N_Z_uperr);
   TGraphAsymmErrors *g_N_Zplus2 = new TGraphAsymmErrors(n_N_Zplus2,x_N_Zplus2,y_N_Zplus2,0,0,yError_N_Zplus2_downerr,yError_N_Zplus2_uperr);
   TGraphAsymmErrors *g_N_Z_MyData = new TGraphAsymmErrors(n_MyData,x_N_Z_MyData,y_N_Z_MyData,0,0,yError_N_Z_MyData_downerr,yError_N_Z_MyData_uperr);
   TGraphAsymmErrors *g_N_Zplus2_MyData = new TGraphAsymmErrors(n_MyData2,x_N_Zplus2_MyData,y_N_Zplus2_MyData,0,0,yError_N_Zplus2_MyData_downerr,yError_N_Zplus2_MyData_uperr);

   // separate the line from the graph
   TGraph *g_N_Z_Line = new TGraph(n_N_Z,x_N_Z,y_N_Z);
   TGraph *g_N_Zplus2_Line = new TGraph(n_N_Zplus2,x_N_Zplus2,y_N_Zplus2);

   g_N_Z->GetXaxis()->SetLimits(31,43);
   g_N_Z->SetMinimum(0.0);
   g_N_Z->SetMaximum(2700.0);
   g_N_Z->GetXaxis()->SetLabelSize(0.06);
   g_N_Z->GetYaxis()->SetLabelSize(0.06);
   g_N_Z->GetXaxis()->SetTitle("Proton number");
   g_N_Z->GetYaxis()->SetTitle("B(E2;2_{1}^{+}#rightarrow 0_{1}^{+}) [#font[12]{e}^{2}fm^{4}]");
   g_N_Z->GetXaxis()->SetTitleOffset(1.05);
   g_N_Z->GetYaxis()->SetTitleOffset(0.975);
   g_N_Z->GetXaxis()->SetTitleSize(0.075);
   g_N_Z->GetYaxis()->SetTitleSize(0.065);
   g_N_Z->GetXaxis()->CenterTitle();
   g_N_Z->GetYaxis()->CenterTitle();
   g_N_Z->GetXaxis()->SetLabelFont(132);
   g_N_Z->GetYaxis()->SetLabelFont(132);
   g_N_Z->GetXaxis()->SetTitleFont(132);
   g_N_Z->GetYaxis()->SetTitleFont(132);

   g_N_Z->SetMarkerStyle(21);
   g_N_Z->SetMarkerSize(1.5);
   g_N_Z->SetMarkerColor(kBlack);
   g_N_Z->Draw("AP");

   g_N_Zplus2->SetMarkerStyle(20);
   g_N_Zplus2->SetMarkerSize(1.5);
   g_N_Zplus2->SetMarkerColor(kBlack);
   g_N_Zplus2->Draw("P same");

   g_N_Z_Line->SetLineWidth(5);
   g_N_Z_Line->SetLineStyle(2);
   g_N_Z_Line->SetLineColor(kBlue);
   g_N_Z_Line->Draw("L same");
   g_N_Zplus2_Line->SetLineWidth(5);
   g_N_Zplus2_Line->SetLineStyle(2);
   g_N_Zplus2_Line->SetLineColor(kGreen+1);
   g_N_Zplus2_Line->Draw("L same");
 
   g_N_Z_MyData->SetMarkerStyle(21);
   g_N_Z_MyData->SetMarkerSize(1.5);
   g_N_Z_MyData->SetMarkerColor(kRed);
   g_N_Z_MyData->SetLineWidth(2);
   g_N_Z_MyData->SetLineColor(kRed);
   g_N_Z_MyData->Draw("P same");

   g_N_Zplus2_MyData->SetMarkerStyle(20);
   g_N_Zplus2_MyData->SetMarkerSize(1.5);
   g_N_Zplus2_MyData->SetMarkerColor(kRed);
   g_N_Zplus2_MyData->SetLineWidth(2);
   g_N_Zplus2_MyData->SetLineColor(kRed);
   g_N_Zplus2_MyData->Draw("P same");

   TLegend *leg = new TLegend(.14,.72,.47,.93,"");
   leg->AddEntry(g_N_Z,"N=Z, literature","p");
   leg->AddEntry(g_N_Zplus2,"N=Z+2, literature","p");
   leg->AddEntry(g_N_Z_MyData,"N=Z, present work","p");
   leg->AddEntry(g_N_Zplus2_MyData,"N=Z+2, present work","p");

   leg->Draw("");
   leg->SetBorderSize(0);
   leg->SetTextFont(132);
   leg->SetTextSize(0.06);

   TLine *l1 = new TLine(39.9,(BE2_80Zr_upper+BE2_80Zr_lower)/2.,41.9,BE2_84Mo_val);
   l1->SetLineStyle(2);
   l1->SetLineColor(kBlue);
   l1->SetLineWidth(5);
   l1->Draw("same");

   TLine *l2 = new TLine(40.1,(BE2_82Zr_upper+BE2_82Zr_lower)/2.,42.1,(BE2_86Mo_upper+BE2_86Mo_lower)/2.);
   l2->SetLineStyle(2);
   l2->SetLineColor(kGreen+1);
   l2->SetLineWidth(5);
   l2->Draw("same");

   TLatex *t1 = new TLatex(41.1,2370.,"^{84}Mo");
   t1->SetTextSize(0.08);
   t1->SetTextColor(kRed);
   t1->Draw();

   TLatex *t2 = new TLatex(41.1,400.,"^{86}Mo");
   t2->SetTextSize(0.08);
   t2->SetTextColor(kRed);
   t2->Draw();

}

