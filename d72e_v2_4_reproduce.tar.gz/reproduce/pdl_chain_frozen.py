"""Frozen chain (v53) and external arbiter (C0)."""
from pdl_common import *
fp = check_chain()
r = ppm(G_PRED, G_CODATA)
print(json.dumps({"fingerprint": fp, "alpha_inv": ALPHA_INV, "x": "7/12", "delta_pct": 100*DELTA,
  "epsilon": EPS, "alpha_G": ALPHA_G, "G_pred": G_PRED, "arbiter_ppm": r, "arbiter_sigma": r/U_G_PPM,
  "u_eps_ppm": U_EPS_PPM}, indent=2))
verdict(abs(r-3.96) < 0.01 and abs(r/U_G_PPM-0.18) < 0.005, "C0: G_pred at +3.96 ppm = +0.18 sigma")
