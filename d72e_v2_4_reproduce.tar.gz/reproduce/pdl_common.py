"""Shared frozen chain and helpers for the D72e v2.4 reproduction scripts.
Standard library only. Every script imports this module and recomputes from it."""
import math, json, hashlib, sys

# ---- Frozen chain (v53 sealed block, as in D72e v1 pipeline v55) ----
ALPHA_INV = 137 + 33/917
ALPHA = 1/ALPHA_INV
N_RUNGS = 18
X = 7/12                                   # reading retained v50-v52 (see corrigendum box)
CHORD = 2*(1 - math.cos(math.pi/N_RUNGS))
ARC = (math.pi/N_RUNGS)**2
DELTA = (1-X)*CHORD + X*ARC                # 3.0429555... %
EPS = ALPHA*(1+DELTA)
ALPHA_G = EPS**N_RUNGS
HBAR = 1.054571817e-34
C_LIGHT = 299792458.0
MP = 1.67262192369e-27                     # proton mass as frozen at v53 (CODATA 2018)
G_PRED = ALPHA_G*HBAR*C_LIGHT/MP**2
MU = 1836.15267343                         # proton-electron mass ratio (CODATA 2018)

# ---- External arbiter and targets ----
G_CODATA = 6.67430e-11; U_G_PPM = 22.0     # CODATA 2022 (unchanged from 2018)
DR_T = 0.04795969; U_DR = 6.98e-8          # D71 target T1
F_T = 0.157126;    U_F = 9e-4              # D71 target T2 (Planck 2018 via D70)
U_EPS_PPM = U_G_PPM/N_RUNGS                # propagated from u_r(G) through the 18th power
U_DR_PPM = U_DR/DR_T*1e6
U_F_PPM = U_F/F_T*1e6

VOC2 = ALPHA**2                            # (v/c)^2 with v = alpha c

def ppm(a, b):
    return (a-b)/b*1e6

def c_disc(n=918):
    return (2*math.sin(math.pi/n))**2      # discrete signed curvature

def c_cont(n=918):
    return (2*math.pi/n)**2

# champions of the two falsifier legs (carried from v63)
D_CHAMP = EPS*2*math.pi*(1+1/66)
F_CHAMP = 1731/11017

def fingerprint():
    pred = {"alpha_inv": ALPHA_INV, "delta_pct": 100*DELTA, "epsilon": EPS,
            "alpha_G": ALPHA_G, "G_pred": G_PRED}
    return hashlib.sha256(json.dumps(pred, sort_keys=True).encode()).hexdigest()[:16]

FROZEN_FP = "7dafad88dd4797d5"

def check_chain():
    fp = fingerprint()
    if fp != FROZEN_FP:
        print("CHAIN INTEGRITY FAIL", fp); sys.exit(1)
    return fp

def p_post(residual_ppm, window, n):
    """Canonical look-elsewhere convention: per-member probability of falling within
    |residual| of the target when uniformly spread over a window of relative width `window`."""
    p1 = min(2*abs(residual_ppm)*1e-6/window, 1.0)
    return p1, 1-(1-p1)**n

def verdict(ok, label):
    print(("PASS " if ok else "FAIL ")+label)
    if not ok: sys.exit(1)
