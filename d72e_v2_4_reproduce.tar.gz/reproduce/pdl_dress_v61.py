"""Gate 29 (v61): dressing k = 1 - (v/c)^2/3 of 77/10240; canonical statistics."""
from pdl_common import *
check_chain()
e1 = 77/10240*(1-VOC2/3); r1 = ppm(e1, EPS); N = 1128; w = 1/math.sqrt(16524)
p1, pp = p_post(r1, w, N)
print(json.dumps({"residual_ppm": r1, "residual_sigma_eps": r1/U_EPS_PPM, "-500(v/c)^4_ppm": -500*VOC2**2*1e6,
  "p1": p1, "p_post": pp}, indent=2))
verdict(abs(r1+1.417) < 0.005 and pp > 0.3, "Gate 29: residual -1.417 ppm (%.2f sigma of u(eps)); p_post = %.4f -> form-hit" % (r1/U_EPS_PPM, pp))
