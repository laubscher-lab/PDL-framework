"""v63 diagnostic: required corrections of the two legs, with target uncertainties."""
from pdl_common import *
check_chain()
xd = ppm(D_CHAMP, DR_T); xf = ppm(F_CHAMP, F_T)
print(json.dumps({"d_r_ppm": xd, "u_dr_ppm": U_DR_PPM, "d_r_sigma": xd/U_DR_PPM,
  "f_ppm": xf, "u_f_ppm": U_F_PPM, "f_sigma": xf/U_F_PPM}, indent=2))
verdict(abs(xd/U_DR_PPM) > 20 and abs(xf/U_F_PPM) < 0.01, "single real leg: d_r at %.2f sigma; f at %.4f sigma" % (xd/U_DR_PPM, abs(xf/U_F_PPM)))
