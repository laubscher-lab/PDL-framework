"""Protocol v2: derived windows. The 'Fano' window equals 1/18 by construction (16524 = 51 x 18^2)."""
from pdl_common import *
check_chain()
w = {"rung": 1/math.sqrt(51), "rung_set": 1/math.sqrt(918), "cascade": 1/math.sqrt(16524)}
w_fano = math.sqrt(51)/math.sqrt(16524)
print(json.dumps({**w, "fano": w_fano, "16524 == 51*18**2": 16524 == 51*18**2}, indent=2))
verdict(abs(w_fano-1/18) < 1e-15 and 16524 == 51*18**2, "w_fano = 1/18 (definitional identity, not an empirical result)")
