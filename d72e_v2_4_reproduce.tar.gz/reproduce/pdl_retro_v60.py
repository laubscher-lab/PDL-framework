"""v60 retro-audit: 77/10240 against the chain epsilon, canonical convention."""
from pdl_common import *
check_chain()
r0 = ppm(77/10240, EPS); w = 1/math.sqrt(16524); N = 1100
p1, pp = p_post(r0, w, N)
p1_old = 2*abs(r0)*1e-6; pp_old = 1-(1-p1_old)**N      # erroneous v2-v2.1 convention, for the record
print(json.dumps({"residual_ppm": r0, "window": w, "N": N, "p1": p1, "p_post": pp,
  "withdrawn_v2_v21": {"p1": p1_old, "p_post": pp_old}}, indent=2))
verdict(pp > 0.95, "77/10240 is not above campaign noise (p_post = %.4f); rehabilitation withdrawn" % pp)
