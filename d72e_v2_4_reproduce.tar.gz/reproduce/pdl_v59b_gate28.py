"""Gate 28 (v59b): closure register {18,36,51,133} vs witnesses {17,37,52,127}; carried NULL."""
from pdl_common import *
check_chain()
rf = ppm(F_CHAMP, F_T); rd = ppm(D_CHAMP, DR_T)
print(json.dumps({"f_champion_ppm": rf, "d_champion_ppm": rd,
  "closures": [18, 36, 51, 133], "witnesses": [17, 37, 52, 127]}, indent=2))
verdict(abs(rd) > 5 and abs(rf) > 5, "Gate 28 NULL: no joint closure at the declared +/-5 ppm")
