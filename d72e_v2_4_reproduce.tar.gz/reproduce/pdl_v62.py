"""Gate 30 (v62): (v/c)^4 term; the '500' reading uses a truncated mass ratio."""
from pdl_common import *
check_chain()
need = (EPS/(77/10240*(1-VOC2/3)) - 1)/VOC2**2
print(json.dumps({"c4_needed": need, "918/1.836": 918/1.836, "918000/mu": 918000/MU,
  "residual_with_500_ppm": ppm(77/10240*(1-VOC2/3+500*VOC2**2), EPS)}, indent=2))
verdict(abs(918/1.836-500) < 1e-12, "918/1.836 = 500 is arithmetic (1.836 = 918/500); graded measured, not derived")
