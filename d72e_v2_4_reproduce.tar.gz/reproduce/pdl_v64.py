"""Gate 32 (v64): post-hoc dressing series of the frozen chain value,
   eps = (77/10240) [1 - (v/c)^2/3 + c4 (v/c)^4],  v = alpha c.
   c4 is fixed by saturating the residual of the frozen value; it is not derived."""
from pdl_common import *
check_chain()
e0 = 77/10240
c4_sat = (EPS/e0 - 1 + VOC2/3)/VOC2**2
c4_per_ppm = 1e-6/VOC2**2                    # change of c4 that moves eps by 1 ppm
c4_band = (c4_sat - U_EPS_PPM*c4_per_ppm, c4_sat + U_EPS_PPM*c4_per_ppm)
members = {"918000/mu": 918000/MU, "500": 500.0, "16524/33": 16524/33, "11017/22": 11017/22}
res = {k: ppm(e0*(1-VOC2/3+v*VOC2**2), EPS) for k, v in members.items()}
print(json.dumps({"c4_saturating": c4_sat, "c4_band_within_u_eps": c4_band,
  "members": members, "residuals_ppm": res, "delta_frozen_pct": 100*DELTA}, indent=2))
verdict(c4_band[0] < 100 and c4_band[1] > 900,
        "c4 = %.2f saturates the frozen value; any c4 in [%.0f, %.0f] is within u(eps): consistency dressing, not a derivation" % (c4_sat, *c4_band))
