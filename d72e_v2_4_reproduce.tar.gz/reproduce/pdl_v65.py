"""Gate 33 (v65): flux-leg border correction 1/(33 x 918); compared with u(f)."""
from pdl_common import *
check_chain()
fc = F_CHAMP*30295/30294; r = ppm(fc, F_T)
print(json.dumps({"f_border_ppm": r, "u_f_ppm": U_F_PPM, "ratio_to_u_f": abs(r)/U_F_PPM}, indent=2))
verdict(abs(r) < 0.01, "f border member at %.5f ppm, i.e. %.1e of u(f): no empirical weight" % (r, abs(r)/U_F_PPM))
