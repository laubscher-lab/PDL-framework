"""Gate 34 (v66): signed curvature with the continuum c = (2 pi/918)^2; joint window +/-0.5 ppm."""
from pdl_common import *
check_chain()
c = c_cont(); kd = 8/9; kf = 1/math.sqrt(2)
rd = ppm(D_CHAMP*(1-kd*c), DR_T); rf = ppm(F_CHAMP*(1+kf*c), F_T)
print(json.dumps({"c_ppm": c*1e6, "d_res_ppm": rd, "f_res_ppm": rf}, indent=2))
verdict(abs(rd) <= 0.5 and abs(rf) <= 0.5, "joint WIN0.5 (form-hit; signs set by the mechanism's construction)")
