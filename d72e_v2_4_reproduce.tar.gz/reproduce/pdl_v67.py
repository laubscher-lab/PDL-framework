"""Gate 35 (v67): D1 ratio and site variation.
D1 is not independent evidence: the distance |kd/kf - measured ratio| is a fixed function
of the two leg residuals, which are already reported. It is reconstructed here from them."""
from pdl_common import *
check_chain()
c = c_disc(); cp = c*1e6
xd = ppm(D_CHAMP, DR_T); xf = ppm(F_CHAMP, F_T)
kd_req = (1 - DR_T/D_CHAMP)/c; kf_req = (F_T/F_CHAMP - 1)/c   # coefficients closing each leg exactly
meas = kd_req/kf_req                                               # D1 target ratio
out = {"measured_ratio": meas, "kd_req": kd_req, "kf_req": kf_req}
ok = True
for name, (kd, kf) in {"8/9 x 1/sqrt2": (8/9, 1/math.sqrt(2)), "8/9 x 12/17": (8/9, 12/17)}.items():
    rd = ppm(D_CHAMP*(1-kd*c), DR_T); rf = ppm(F_CHAMP*(1+kf*c), F_T)
    direct = abs(kd/kf - meas)
    kd_back = (1 - DR_T*(1+rd*1e-6)/D_CHAMP)/c; kf_back = (F_T*(1+rf*1e-6)/F_CHAMP - 1)/c
    from_res = abs(kd_back/kf_back - meas)                        # D1 rebuilt from the residuals alone
    out[name] = {"d_res": rd, "f_res": rf, "D1_direct": direct, "D1_from_residuals": from_res}
    ok &= abs(direct - from_res) < 1e-8
q = 8/9*(c - c_disc(919))*1e6
out.update({"q_link_ppm": q, "q_link_over_u_dr": q/U_DR_PPM})
print(json.dumps(out, indent=2))
verdict(ok and q/U_DR_PPM < 0.1, "D1 is reconstructed from the two residuals (no independent content); q_link = %.4f ppm = %.3f u(d_r), untestable" % (q, q/U_DR_PPM))
