"""Gate 36 (v68): exact discrete curvature; champion and convergent counter-pair."""
from pdl_common import *
check_chain()
c = c_disc()
out = {"c_ppm": c*1e6, "rel_diff_cont": c_cont()/c-1}
for name, (kd, kf) in {"champion 8/9 x 1/sqrt2": (8/9, 1/math.sqrt(2)), "counter 8/9 x 12/17": (8/9, 12/17)}.items():
    out[name] = {"d_res_ppm": ppm(D_CHAMP*(1-kd*c), DR_T), "f_res_ppm": ppm(F_CHAMP*(1+kf*c), F_T)}
print(json.dumps(out, indent=2))
ch, co = out["champion 8/9 x 1/sqrt2"], out["counter 8/9 x 12/17"]
verdict(abs(co["f_res_ppm"]) < abs(ch["f_res_ppm"]) and abs(ch["d_res_ppm"]) <= 0.5, "counter-pair 8/9 x 12/17 is tighter on f than the champion")
