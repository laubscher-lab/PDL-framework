"""Gate 37 (v69): dense rational grid, denominators q <= 51 on both legs."""
from pdl_common import *
from fractions import Fraction
check_chain()
c = c_disc()
ch_d = abs(ppm(D_CHAMP*(1-8/9*c), DR_T)); ch_f = abs(ppm(F_CHAMP*(1+c/math.sqrt(2)), F_T))
ch_joint = max(ch_d, ch_f)
kd_ok = sorted({Fraction(p, q) for q in range(2, 52) for p in range(1, q) if abs(ppm(D_CHAMP*(1-p/q*c), DR_T)) < ch_joint})
kf_ok = sorted({Fraction(p, q) for q in range(2, 52) for p in range(1, q) if abs(ppm(F_CHAMP*(1+p/q*c), F_T)) < ch_joint})
pairs = sorted((max(abs(ppm(D_CHAMP*(1-float(a)*c), DR_T)), abs(ppm(F_CHAMP*(1+float(b)*c), F_T))), str(a), str(b)) for a in kd_ok for b in kf_ok)
print(json.dumps({"champion_joint_ppm": ch_joint, "n_pairs_beating_champion": len(pairs), "best": pairs[:3]}, indent=2))
verdict(len(pairs) > 0, "absolute uniqueness refuted on the q <= 51 grid (%d pairs beat the champion)" % len(pairs))
