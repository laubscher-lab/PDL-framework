"""Gate 38 (v70): computed A1-A4 filter (axioms formulated after gate 37).
A1: prime atoms of numerator and denominator in {2,3,7,11,17}.
A2: L(p/q) = Omega(p) + Omega(q) <= 6 (prime factors counted with multiplicity), lowest terms.
A3: signed curvature, d -> d(1 - kd c), f -> f(1 + kf c), 0 < kd < 1.
A4: kf = 1/sqrt(2) or a convergent of 1/sqrt(2) satisfying A1-A2.
Window: the joint window declared at gate 34, |res| <= 0.5 ppm on both legs."""
from pdl_common import *
from fractions import Fraction
import itertools
check_chain()
ATOMS = (2, 3, 7, 11, 17)
def omega(n):
    k = 0
    for p in ATOMS:
        while n % p == 0: n //= p; k += 1
    return k if n == 1 else None
nums = {1} | {math.prod(cmb) for L in range(1, 7) for cmb in itertools.combinations_with_replacement(ATOMS, L)}
kd_all = sorted({Fraction(p, q) for p in nums for q in nums if 0 < Fraction(p, q) < 1
                 and omega(Fraction(p, q).numerator) + omega(Fraction(p, q).denominator) <= 6})
conv = []; h0, h1, k0, k1 = 1, 0, 0, 1
for t in [1] + [2]*12:
    h0, h1 = h1, t*h1 + h0; k0, k1 = k1, t*k1 + k0; conv.append(Fraction(h1, k1))
kf_all = [("1/sqrt2", 1/math.sqrt(2))] + [(str(v), float(v)) for v in conv
          if omega(v.numerator) is not None and omega(v.denominator) is not None
          and omega(v.numerator) + omega(v.denominator) <= 6]
c = c_disc()
rows = []
for kd in kd_all:
    rd = ppm(D_CHAMP*(1-float(kd)*c), DR_T)
    for name, kf in kf_all:
        rf = ppm(F_CHAMP*(1+kf*c), F_T)
        if abs(rd) <= 0.5 and abs(rf) <= 0.5:
            rows.append({"kd": str(kd), "kf": name, "d_res_ppm": round(rd, 4), "f_res_ppm": round(rf, 4)})
radial_within_u = [(str(k), round(ppm(D_CHAMP*(1-float(k)*c), DR_T), 3)) for k in kd_all
                   if abs(ppm(D_CHAMP*(1-float(k)*c), DR_T)) <= U_DR_PPM]
print(json.dumps({"n_kd_candidates": len(kd_all), "kf_candidates": [n for n, _ in kf_all],
  "admissible_pairs": rows, "n_admissible": len(rows),
  "radial_coefficients_within_u_dr": radial_within_u}, indent=2))
verdict(len(rows) == 6, "%d admissible pairs under A1-A4 and WIN0.5: selector admissible, not unique" % len(rows))
