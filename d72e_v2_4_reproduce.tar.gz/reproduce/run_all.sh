#!/bin/sh
# Runs every reproduction script; stops at the first failure.
set -e
for s in pdl_chain_frozen pdl_protocol_v59 pdl_v59b_gate28 pdl_retro_v60 pdl_dress_v61 pdl_v62 pdl_joint_v63 pdl_v64 pdl_v65 pdl_v66 pdl_v67 pdl_v68 pdl_v69 pdl_v70; do
  echo "=== $s"; python3 "$s.py"
done
echo "ALL PASS"
